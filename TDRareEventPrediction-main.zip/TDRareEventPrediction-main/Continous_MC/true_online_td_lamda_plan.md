# True Online TD(λ) Implementation Plan

This document outlines the design and implementation of the True Online TD(λ) algorithm using the updated preprocessing pipeline and the CNN1D model as a value function approximator.

---

## 1. Overview

True Online TD(λ) is an online learning algorithm that updates a value function using eligibility traces in a “true online” fashion. It combines multi-step returns with a recency-weighted average using the λ parameter. The method has the following advantages over conventional TD(λ):
- Improved stability and convergence properties.
- More efficient online updates, as it avoids the need to store entire trajectories.
- Correct handling of non-linear function approximators (e.g., neural networks).

In this implementation, we use:
- **Preprocessing:** Existing functions (`prepare_data`, `process_input_data_with_targets`, etc.) to generate sliding windows for sensor data and the associated targets.
- **Function Approximation:** A CNN1D network that outputs a value prediction for a given window of sensor data.
- **True Online TD(λ) Logic:** 
  - Maintain a running eligibility trace for each parameter in the network.
  - Compute the TD error and update the model and the eligibility traces online.
  
---

## 2. Data Preparation

- **Data Loading & Preprocessing:**
  - **Prepare Data:** Use `prepare_data` to load train and test data along with RUL values.
  - **Sliding Windows:** For each engine, call `process_input_data_with_targets` to generate the sliding windows for sensor data, which act as states.
- **Dataset & DataLoader:**
  - Create a custom dataset (e.g., `RULDataset`) that yields complete sequences or sliding windows.
  - The data batch shape will be `(batch_size, sequence_length, num_features)` where `sequence_length` is determined by the chosen window size.

---

## 3. Model Architecture

- **CNN1D Model:**  
  - Use the existing CNN1D from our project as the function approximator to predict the value function \( V(s) \).
  - Ensure that the model can handle inputs from sliding windows and is compatible with PyTorch.

- **Parameters:**
  - **Input Channels:** Equal to the number of sensor features.
  - **Output:** A single scalar value that estimates the value (or RUL) at the input state.

---

## 4. True Online TD(λ) Algorithm Details

### 4.1. Hyperparameters

- **Discount Factor (γ):** Controls the weight given to future rewards.
- **Trace-decay Parameter (λ):** Determines the weighting of multi-step returns; typically \(\lambda \in [0,1]\).
- **Learning Rate:** For optimizing the CNN1D parameters.
- **Window Size:** The length of the sliding window (i.e., the state representation).
- **Early RUL Parameter:** Used for the reward logic (e.g., piecewise rewards based on early degradation).

### 4.2. Eligibility Traces

For each model parameter \(\theta\), maintain an eligibility trace \( e \) that is updated on each step:
- **Initialization:** Set \( e = 0 \) (i.e., zeros of the same shape as the model parameters).
- **Update Rule (True Online Correction):**
  - Compute the gradient of the current value prediction \( V(s_t) \) with respect to \(\theta\).
  - Update eligibility traces using:
    \[
    e \leftarrow \gamma \lambda e + \nabla_\theta V(s_t) - \gamma \lambda (e^\top \theta) \nabla_\theta V(s_t)
    \]
  - (Note: The above is illustrative. Depending on your chosen formulation, be sure that the update corresponds to the "true online" formulation as described by van Seijen et al.)

### 4.3. TD Error & Update

At each step \( t \) for a given sliding window:
- **State and Reward:**
  - Extract the current state \( s_t \) (i.e., a window of sensor data).
  - Define the immediate reward \( r_t \) as:
    - \( r_t = 0 \) if the RUL prediction is above the `early_rul` threshold.
    - \( r_t = 1 \) otherwise.
- **Temporal Difference Error (δ):**
  \[
  \delta_t = r_t + \gamma V(s_{t+1}) - V(s_t)
  \]
  - If \( s_{t+1} \) is not available (terminal state), then use \( V(s_{t+1}) = 0 \).
- **Parameter Update:**
  - Update the model parameters using gradient descent:
    \[
    \theta \leftarrow \theta + \alpha \delta_t e
    \]
  - Simultaneously update the eligibility traces as described above.
  
- **True Online Correction:** Ensure that the algorithm’s updates include the corrections that make it "true online TD(λ)" as opposed to the conventional TD(λ).

---

## 5. Detailed Pseudocode
Initialize model parameters θ
Set eligibility traces e = 0 for all θ
For each epoch:
For each batch in the training DataLoader:
For each time step t in the sequence (t = 0, 1, ..., num_windows - 1):
s_t = current state (from sliding window)
V_t = model(s_t)
if t < num_windows - 1:
s_t+1 = next state (sliding window at t+1)
V_t1 = model(s_t+1)
else:
V_t1 = 0 // terminal state
r_t = compute_reward(s_t) // based on RUL or custom logic
δ = r_t + γ V_t1 - V_t
grad_Vt = ∇θ V(s_t) // compute gradient for current state
// Update the eligibility traces with true online correction
e = γ λ e + grad_Vt - γ λ (e ⋅ θ) grad_Vt
// Update the model parameters using the TD error and eligibility traces
θ = θ + α δ e

---

## 6. Integration & Code Structure

- **Function:**  
  Create a new function `train_true_online_td_lambda_model` in `src/td_algorithm.py` that:
  - Loads the preprocessed data.
  - Implements the training loop as described in the pseudocode.
  - Uses PyTorch for automatic differentiation and parameter updates.
  
- **Validation:**
  - Implement a validation routine (similar to `compute_true_val_error`) to calculate RMSE over the validation set.
  - Save the best performing model based on the validation error.
  
- **Logging:**
  - Log training progress (TD error, loss, and eligibility trace norms) for debugging and analysis.

---

## 7. Testing & Future Considerations

- **Debugging:**
  - Test the algorithm on a small mini-batch to ensure the eligibility traces evolve as expected.
  - Compare with conventional TD(0) to verify improvements.
  
- **Vectorization & Efficiency:**
  - Consider vectorized implementations for batch operations to improve training speed.
  - Investigate approaches to efficiently accumulate gradients for large models.

- **Hyperparameter Tuning:**
  - Experiment with different values for λ, γ, and the learning rate α.
  - Adjust the window size and reward function based on domain-specific requirements (e.g. early degradation detection).

---

## 8. Summary

This plan outlines how to build a True Online TD(λ) algorithm using our current infrastructure. It integrates data preprocessing, sliding window generation, a CNN1D-based value function approximator, and the true online TD(λ) update mechanism to learn value predictions for RUL. Future improvements might include further optimization, hyperparameter tuning, and additional evaluation metrics.
