#%%
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

def simulate_flips(p, n_flips, n_trials):
    """
    Simulate n_trials of flipping a biased coin n_flips times.
    
    Parameters:
    - p: Probability of getting heads.
    - n_flips: Number of coin flips per trial.
    - n_trials: Number of trials to simulate.
    
    Returns:
    - flips: A 2D numpy array of shape (n_trials, n_flips) with 1s for heads and 0s for tails.
    """
    return np.random.binomial(1, p, size=(n_trials, n_flips))

def estimate_p(estimator_type, flips=None, n_trials=None):
    """
    Estimate the probability of heads using different estimation methods.
    
    Parameters:
    - estimator_type: Type of estimator ('full', 'impatient', 'blind').
    - flips: A 2D numpy array with coin flip results (required for 'full' and 'impatient').
    - n_trials: Number of trials to simulate (required for 'blind').
    
    Returns:
    - estimates: Estimated p values from the specified estimator.
    """
    if estimator_type == 'full':
        return flips.mean(axis=1)
    elif estimator_type == 'impatient':
        return flips[:, :5].mean(axis=1)
    elif estimator_type == 'blind':
        return np.full(n_trials, 0.5)
    else:
        raise ValueError("Unknown estimator type.")

def compute_statistics(true_p, estimates):
    """
    Compute the empirical risk, bias, and variance of an estimator.
    
    Parameters:
    - true_p: The true probability of heads.
    - estimates: Estimated p values from the estimator.
    
    Returns:
    - stats: A dictionary containing 'risk', 'bias', and 'variance'.
    """
    squared_errors = (true_p - estimates) ** 2
    risk = np.mean(squared_errors)
    bias = np.mean(estimates) - true_p
    variance = np.var(estimates)
    return {'risk': risk, 'bias': bias, 'variance': variance}

def theoretical_risk(p, n_flips, estimator_type):
    """
    Compute the theoretical risk for a given estimator.
    
    Parameters:
    - p: True probability of heads.
    - n_flips: Number of coin flips used in the estimator.
    - estimator_type: Type of estimator ('full', 'impatient', 'blind').
    
    Returns:
    - risk: Theoretical risk.
    """
    if estimator_type == 'full':
        variance = p * (1 - p) / n_flips
        bias = 0
    elif estimator_type == 'impatient':
        n_flips_impatient = 5
        variance = p * (1 - p) / n_flips_impatient
        bias = 0
    elif estimator_type == 'blind':
        bias = p - 0.5
        variance = 0
    else:
        raise ValueError("Unknown estimator type.")
    
    risk = bias**2 + variance
    return risk

if __name__ == "__main__":
#%%
    # Set random seed for reproducibility
    np.random.seed(42)
    
    # Parameters
    p_values = np.arange(0.0, 1.1, 0.1)
    n_flips_full = 10
    n_flips_impatient = 5
    n_trials = 10000
    estimators = ['full', 'impatient', 'blind']
    
    # Initialize dictionaries to store results
    results = {
        'risk': {est: [] for est in estimators},
        'bias': {est: [] for est in estimators},
        'variance': {est: [] for est in estimators},
        'theoretical_risk': {est: [] for est in estimators}
    }
    
    for p in p_values:
        # Simulate flips for 'full' and 'impatient' estimators
        flips = simulate_flips(p, n_flips_full, n_trials)
        
        for est in estimators:
            if est in ['full', 'impatient']:
                est_flips = flips
                est_n_flips = n_flips_full if est == 'full' else n_flips_impatient
                estimates = estimate_p(est, flips=est_flips, n_trials=n_trials)
            elif est == 'blind':
                estimates = estimate_p(est, n_trials=n_trials)
            
            # Compute empirical statistics
            stats = compute_statistics(p, estimates)
            results['risk'][est].append(stats['risk'])
            results['bias'][est].append(stats['bias'])
            results['variance'][est].append(stats['variance'])
            
            # Compute theoretical risk
            theo_risk = theoretical_risk(p, n_flips_full if est == 'full' else n_flips_impatient if est == 'impatient' else 0, est)
            results['theoretical_risk'][est].append(theo_risk)
    
    # Plotting Empirical vs Theoretical Risks
    plt.figure(figsize=(12, 8))
    colors = {'full': 'blue', 'impatient': 'orange', 'blind': 'green'}
    markers = {'full': 'o', 'impatient': 's', 'blind': '^'}
    
    for est in estimators:
        plt.plot(p_values, results['risk'][est], label=f'Method {estimators.index(est)+1}: {est.capitalize()} Estimator',
                 marker=markers[est], color=colors[est])
        plt.plot(p_values, results['theoretical_risk'][est], linestyle='--', 
                 color=colors[est], alpha=0.5, label=f'Theoretical Risk {est.capitalize()}')
    
    plt.xlabel('True Probability of Heads (p)')
    plt.ylabel('Empirical Risk (Squared Error)')
    plt.title('Risk Functions of Different Estimators for Coin Flip Probability')
    plt.legend()
    plt.grid(True)
    plt.show()
    
    # Plotting Bias and Variance
    plt.figure(figsize=(14, 6))
    
    # Bias Plot
    plt.subplot(1, 2, 1)
    for est in estimators:
        plt.plot(p_values, results['bias'][est], label=f'Method {estimators.index(est)+1}: {est.capitalize()} Estimator',
                 marker=markers[est], color=colors[est])
    plt.xlabel('True Probability of Heads (p)')
    plt.ylabel('Bias')
    plt.title('Bias of Estimators')
    plt.legend()
    plt.grid(True)
    
    # Variance Plot
    plt.subplot(1, 2, 2)
    for est in estimators:
        plt.plot(p_values, results['variance'][est], label=f'Method {estimators.index(est)+1}: {est.capitalize()} Estimator',
                 marker=markers[est], color=colors[est])
    plt.xlabel('True Probability of Heads (p)')
    plt.ylabel('Variance')
    plt.title('Variance of Estimators')
    plt.legend()
    plt.grid(True)
    
    plt.tight_layout()
    plt.show()
    
    # Print Empirical and Theoretical Risks
    print("Empirical and Theoretical Risks:")
    header = f"{'p':>3} | " + " | ".join([f"{est.capitalize()} Empirical".ljust(20) + f" | {est.capitalize()} Theoretical".ljust(25) for est in estimators])
    print(header)
    print("-" * len(header))
    for i, p in enumerate(p_values):
        row = f"{p:.1f} | "
        for est in estimators:
            emp_risk = results['risk'][est][i]
            theo_risk = results['theoretical_risk'][est][i]
            row += f"{emp_risk:<20.5f} | {theo_risk:<25.5f} | "
        print(row.rstrip(' | '))
    
    # Print Bias and Variance
    print("\nBias and Variance:")
    bias_header = f"{'p':>3} | " + " | ".join([f"{est.capitalize()} Bias".ljust(15) for est in estimators])
    variance_header = f"{'p':>3} | " + " | ".join([f"{est.capitalize()} Variance".ljust(18) for est in estimators])
    print(bias_header)
    print("-" * len(bias_header))
    for i, p in enumerate(p_values):
        row = f"{p:.1f} | " + " | ".join([f"{results['bias'][est][i]:<15.5f}" for est in estimators])
        print(row)
    print("\n" + variance_header)
    print("-" * len(variance_header))
    for i, p in enumerate(p_values):
        row = f"{p:.1f} | " + " | ".join([f"{results['variance'][est][i]:<18.5f}" for est in estimators])
        print(row)


# %%
