import torch
import numpy as np
from torch.utils.data import DataLoader
from train import CNN1D, RULDataset
from preprocessing import prepare_data, process_input_data_with_targets, process_targets
from sklearn.model_selection import train_test_split
import os
from sklearn.metrics import mean_squared_error
from tqdm import tqdm

def compute_true_val_error(model, val_dataset, window_size):
    """
    Compute the 'true' validation error by forwarding the entire validation dataset,
    extracting the prediction from the last sliding window, and comparing it to the true RUL.
    
    Parameters:
      model: The trained model.
      val_dataset: The validation dataset (an instance of RULDataset or similar).
      window_size: The size of the sliding window.
    
    Returns:
      rmse: The RMSE computed over the validation engines.
    """
    model.eval()
    all_preds = []
    all_true = []
    
    # The following loop assumes that each sample in your dataset corresponds to one engine's full sequence.
    for features, targets in val_dataset:
        features = features.unsqueeze(0).to(model.device)  # Add a batch dimension
        targets = targets.unsqueeze(0).to(model.device)
        sequence_length = features.size(1)
        num_windows = sequence_length - window_size + 1
        
        # Extract prediction from the last sliding window.
        last_window = features[:, num_windows - 1:num_windows - 1 + window_size, :]
        pred = model(last_window).squeeze().detach().cpu().item()
        true_val = targets[:, -1].squeeze().detach().cpu().item()  # Assuming last value is the true RUL
        
        all_preds.append(pred)
        all_true.append(true_val)
    
    rmse = np.sqrt(mean_squared_error(all_true, all_preds))
    return rmse

def train_true_online_td_lambda_model(train_data: np.ndarray, 
                                      train_targets: np.ndarray,
                                      batch_size: int = 1,
                                      epochs: int = 20,
                                      learning_rate: float = 0.001,
                                      model_save_path: str = "saved_models",
                                      model_name: str = "true_online_td_lambda",
                                      use_piecewise: bool = True,
                                      early_rul: int = 125,
                                      gamma: float = 0.999,
                                      lambd: float = 0.9,
                                      window_size: int = 30) -> CNN1D:
    """
    Train a CNN1D model using True Online TD(λ) updates.
    
    In this implementation, each training sample (an episode) is processed sequentially.
    For each episode, eligibility traces are initialized to zero and updated over time.
    The update rule follows the True Online TD(λ) algorithm:
    
       δ_t = r_t + γ V(s_{t+1}) - V(s_t)
       e_t = γλ e_{t-1} + (1 - α γλ (e_{t-1}ᵀ grad_t)) grad_t
       w ← w + α [ (δ_t + V(s_t) - V_old) e_t - (V(s_t) - V_old) grad_t ]
       V_old is updated to V(s_{t+1})
    
    Parameters:
      train_data: Preprocessed training data with shape (num_samples, full_sequence_length, num_features).
      train_targets: Preprocessed RUL targets with shape (num_samples, full_sequence_length).
      batch_size: Batch size (use 1 for true online updates per episode).
      epochs: Number of epochs.
      learning_rate: Step-size α.
      model_save_path: Directory to save model checkpoints.
      model_name: Name to be used for saving the model.
      use_piecewise: Whether to use piecewise reward functions.
      early_rul: Threshold for reward computation.
      gamma: Discount factor.
      lambd: Trace-decay parameter (λ).
      window_size: Length of the sliding window (state representation).
    
    Returns:
      model: The trained CNN1D model with the best validation performance.
    """
    os.makedirs(model_save_path, exist_ok=True)
    
    # Split data into training and validation sets.
    train_data, val_data, train_targets, val_targets = train_test_split(
        train_data, train_targets, test_size=0.2, random_state=83
    )
    
    # Create datasets and dataloaders.
    train_dataset = RULDataset(train_data, train_targets)
    val_dataset   = RULDataset(val_data, val_targets)
    train_loader  = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    
    # Initialize model.
    model = CNN1D(input_channels=train_data.shape[2])
    # Note: We update weights manually in this algorithm, so we do not use an optimizer.
    
    best_val_error = float('inf')
    
    print("Starting True Online TD(λ) training...")
    for epoch in range(epochs):
        model.train()
        total_loss = 0.0
        
        # Use tqdm here for the dataloader loop.
        for batch_features, batch_targets in tqdm(train_loader, desc=f"Epoch {epoch+1}/{epochs}"):
            batch_features = batch_features.to(model.device)  # shape: (1, sequence_length, num_features)
            batch_targets  = batch_targets.to(model.device)   # shape: (1, sequence_length)
            
            sequence_length = batch_features.size(1)
            num_windows = sequence_length - window_size + 1
            if num_windows < 1:
                continue
                
            # Initialize eligibility traces for all parameters (reset per episode)
            eligibility_traces = {name: torch.zeros_like(param, device=model.device)
                                  for name, param in model.named_parameters() if param.requires_grad}
            
            # Get initial value: s₀ is the first sliding window.
            s0 = batch_features[:, 0:window_size, :]
            v_old = model(s0).squeeze()  # scalar; V(s₀)
            
            episode_loss = 0.0
            # Iterate over time steps within the episode
            for t in range(num_windows):
                # Current state: sliding window starting at t
                current_state = batch_features[:, t:t+window_size, :]
                v = model(current_state).squeeze()  # V(s_t)
                
                # Compute reward r_t from the target at the last step of the window.
                current_rul = batch_targets[:, t+window_size-1]
                if use_piecewise:
                    reward = torch.where(current_rul > early_rul,
                                         torch.tensor(0.0, device=model.device),
                                         torch.tensor(1.0, device=model.device))
                else:
                    reward = torch.ones_like(current_rul, device=model.device)
                
                # Compute V(s_{t+1}) if available, else 0 (terminal state)
                if t < num_windows - 1:
                    next_state = batch_features[:, t+1:t+1+window_size, :]
                    v_next = model(next_state).squeeze()
                else:
                    v_next = torch.tensor(0.0, device=model.device)
                
                # TD error δ = r + γ V(s_{t+1}) - V(s_t)
                delta = reward + gamma * v_next - v

                # Compute gradient of V(s_t) with respect to the parameters.
                model.zero_grad()
                v.backward(retain_graph=True)
                
                # Collect gradients for each parameter.
                grads = {}
                for name, param in model.named_parameters():
                    if param.requires_grad and param.grad is not None:
                        grads[name] = param.grad.detach().clone()
                
                # Update eligibility traces for each parameter:
                for name, param in model.named_parameters():
                    if param.requires_grad:
                        e = eligibility_traces[name]
                        grad = grads[name]
                        # Dot product between existing eligibility and current gradient.
                        dot_prod = torch.sum(e.view(-1) * grad.view(-1))
                        # True Online eligibility trace update:
                        eligibility_traces[name] = gamma * lambd * e + (1 - learning_rate * gamma * lambd * dot_prod) * grad
                
                # Perform the weight update manually:
                # Update rule:
                #   Δw = α * [ (δ + V(s_t) - v_old) * e - (V(s_t) - v_old) * grad ]
                for name, param in model.named_parameters():
                    if param.requires_grad:
                        grad = grads[name]
                        e = eligibility_traces[name]
                        update = learning_rate * (delta + (v - v_old)) * e - learning_rate * (v - v_old) * grad
                        param.data.add_(update)
                
                # Update v_old to be V(s_{t+1})
                v_old = v_next.detach()
                
                # Accumulate squared TD error for logging
                episode_loss += (delta.item())**2
            
            total_loss += episode_loss
        
        avg_train_loss = total_loss / len(train_loader.dataset)
        # Compute true validation error using the provided routine.
        true_val_error = compute_true_val_error(model, val_dataset, window_size)
        print(f"Epoch [{epoch+1}/{epochs}], Train Loss: {avg_train_loss:.4f}, Val RUL Error (RMSE): {true_val_error:.4f}")
        
        # Save the best performing model.
        if true_val_error < best_val_error:
            best_val_error = true_val_error
            torch.save(model.state_dict(), os.path.join(model_save_path, f"best_{model_name}.pth"))
            print("Best Model Saved")
    
    model.load_state_dict(torch.load(os.path.join(model_save_path, f"best_{model_name}.pth")))
    return model

def main():
    """
    Main execution for TD algorithm variants.
    This main function demonstrates data preparation, training both the traditional TD and
    True Online TD(λ) models (if desired), and saving the trained models.
    """
    # Prepare data with explicit parameters.
    train_data, test_data, true_rul, sequence_length, shift, early_rul = prepare_data(
        train_path="../CMAPSSData/train_FD001.txt",
        test_path="../CMAPSSData/test_FD001.txt",
        rul_path="../CMAPSSData/RUL_FD001.txt",
        window_length=200,
        shift=1,
        early_rul=125
    )
    
    processed_train_data, processed_train_targets = [], []
    num_train_machines = len(train_data[0].unique())
    
    for i in range(1, num_train_machines + 1):
        # Get sensor-only data for engine i.
        temp_train_data = train_data[train_data[0] == i].drop(columns=[0]).values
        temp_train_targets = process_targets(data_length=temp_train_data.shape[0], early_rul=early_rul)
        
        # Create sliding windows using the full sequence length.
        data_for_machine, targets_for_machine = process_input_data_with_targets(
            temp_train_data, temp_train_targets, window_length=sequence_length, shift=shift, target_for_all_timestamps=True
        )
        processed_train_data.append(data_for_machine)
        processed_train_targets.append(targets_for_machine)
    
    processed_train_data = np.concatenate(processed_train_data)
    processed_train_targets = np.concatenate(processed_train_targets)
    
    print(f"Processed Train Data Shape: {processed_train_data.shape}")
    print(f"Processed Train Targets Shape: {processed_train_targets.shape}")
    
    # Train the model using True Online TD(λ)
    td_lambda_model = train_true_online_td_lambda_model(
        processed_train_data, 
        processed_train_targets, 
        batch_size=1,  # recommended for true online updates per episode
        model_name="true_online_td_lambda",
        use_piecewise=True,
        early_rul=early_rul,
        window_size=30,
        gamma=0.999,
        lambd=0.9,
        learning_rate=0.001,
        epochs=20
    )
    
    # (Optionally, you can also run traditional TD training here.)
    
if __name__ == "__main__":
    print("Running TD algorithm main() with True Online TD(λ)")
    main() 