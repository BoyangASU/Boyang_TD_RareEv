# %%
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
import sys
from Discrete_MC import Discrete_MC

#%%
# =============================================================================
# 2) Baseline Estimators: MC, TD(0), TD(lambda)
# =============================================================================
def monte_carlo_estimator_from_samples(samples, n):
    mfpt = np.zeros(n)
    for start_state in tqdm(range(n), desc="Monte Carlo Simulation from Samples"):
        state_samples = [len(trajectory) for trajectory in samples if trajectory[0][0] == start_state]
        if state_samples:
            mfpt[start_state] = np.mean(state_samples)
    return mfpt

def td_estimator_from_samples(samples, n, alpha, nepoch):
    """
    TD(0) for mean first passage time using pre-generated samples.
    """
    u = np.zeros(n)  # value function
    for _ in tqdm(range(nepoch), desc="TD(0) Learning from Epochs"):
        for trajectory in samples:
            for state, next_state, reward in trajectory:
                # TD(0) update: u[state] <- u[state] + alpha*(reward + u[next_state] - u[state])
                td_error = reward + u[next_state] - u[state]
                u[state] += alpha * td_error
    return u

def td_lambda_estimator_from_samples(samples, n, alpha, nepoch, lambd=0.9):
    """
    TD(lambda) for mean first passage time using pre-generated samples.
    """
    u = np.zeros(n)
    for _ in tqdm(range(nepoch), desc=f"TD(lambda={lambd}) Learning from Epochs"):
        for trajectory in samples:
            e = np.zeros(n)  # eligibility traces
            for state, next_state, reward in trajectory:
                delta = reward + u[next_state] - u[state]
                e[state] += 1.0  # increment trace for current state
                # update all states
                u += alpha * delta * e
                # decay traces
                e *= lambd
    return u

#%%
# =============================================================================
# Main: Compare all mean-based methods
# =============================================================================
if __name__ == "__main__":
    n = 20
    num_samples = 500        # for MC mean AND MC-based quantiles
    num_episodes_td = 60      # for learning-based methods
    num_episodes_lambda = 10  # fro TD Lambda
    alpha_TD = 0.001            # step size for standard TD
    alpha_TD_lambda = 0.001            # step size for standard TD
    lambd = 0.9
    num_quantiles = 21
    kappa = 1.0
   
    # Create an instance of the class
    mc_simulation = Discrete_MC(n)

    # Generate samples
    samples = mc_simulation.generate_samples(num_samples) 


    # Use samples to generate mc_results
    mc_results = monte_carlo_estimator_from_samples(samples, n)
    # Learn from samples
    td_results = td_estimator_from_samples(samples, n, alpha_TD, num_episodes_td)
    td_lambda_results = td_lambda_estimator_from_samples(samples, n, alpha_TD_lambda, num_episodes_lambda, lambd)

    plt.figure(figsize=(12, 7))
    plt.plot(range(n), mc_results, label="MC Mean (Time)", marker="o")
    plt.plot(range(n), td_results, label="TD(0) Mean", marker="s")
    plt.plot(range(n), td_lambda_results, label=f"TD(λ={lambd}) Mean", marker="x")
    plt.xlabel("State")
    plt.ylabel("Mean First Passage Time")
    plt.title("Comparison of Mean-Based Approaches")
    plt.legend()
    plt.grid()
    plt.show()


# %%
