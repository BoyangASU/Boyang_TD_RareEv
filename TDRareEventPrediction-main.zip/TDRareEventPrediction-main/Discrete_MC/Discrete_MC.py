#%%
import numpy as np
from tqdm import tqdm

class Discrete_MC:
    def __init__(self, n):
        """
        Initialize the Markov Chain with a given number of states.
        
        Args:
            n (int): Number of states.
        """
        self.n = n
        self.P, self.p = self.create_transition_matrix()

    def create_transition_matrix(self):
        """
        Create the transition matrix for a 1D nearest-neighbor Markov chain with
        'reflecting' boundaries at 0 and n-1, except here we impose some
        non-uniform behavior using an exponential weighting p.
        
        Returns:
            P: Transition matrix of shape (n, n)
            p: The array used in the probability ratio for transitions
        """
        p = np.exp((self.n - 1) / (4 * np.pi) * np.cos(4 * np.pi * (np.arange(self.n) - 1) / (self.n - 1)))
        p /= p.sum()  # Normalize to get probabilities
        
        P = np.zeros((self.n, self.n))
        for i in range(1, self.n - 1):
            P[i, i - 1] = p[i - 1] / (p[i] + p[i - 1])
            P[i, i + 1] = p[i + 1] / (p[i] + p[i + 1])
            P[i, i] = 1.0 - P[i, i - 1] - P[i, i + 1]
            P[i, i - 1] = max(P[i, i - 1], 0)
            P[i, i + 1] = max(P[i, i + 1], 0)
            P[i, i] = max(P[i, i], 0)
        P[0, 1] = 1.0
        P[self.n - 1, self.n - 2] = 1.0
        P = P / P.sum(axis=1, keepdims=True)
        
        return P, p

    def generate_samples(self, num_episodes):
        """
        Generate samples for TD learning.
        Each sample is a trajectory from a random non-terminal state to an absorbing state.
        
        Args:
            num_episodes (int): Number of trajectories to generate.
        
        Returns:
            samples (list): List of trajectories.
        """
        samples = []
        for _ in range(num_episodes):
            trajectory = []
            state = np.random.randint(1, self.n - 1)
            while state not in [0, self.n - 1]:
                next_state = np.random.choice(self.n, p=self.P[state])
                reward = 1.0
                trajectory.append((state, next_state, reward))
                state = next_state
            samples.append(trajectory)
        return samples

if __name__ == "__main__":
    # Parameters
    n = 20
    num_samples = 500
    num_episodes_td = 60
    alpha_TD = 0.001
    nepoch = 10

    # Create an instance of the class
    mc_simulation = Discrete_MC(n)

    # Generate samples
    samples = mc_simulation.generate_samples(num_samples)
    print(samples)

